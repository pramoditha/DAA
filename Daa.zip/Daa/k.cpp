#include <iostream>
using namespace std;
int main() 
{
    int i,n=0;   
    int idealCount = 0, nonIdealCount = 0, faultyCount = 0;
    cout<<"Enter the number of eggs"<<endl;
    cin>>n;
    
    float weight[n];
    cout<<"Enter the weight of the eggs(in grams)"<<endl;
    for (i=0;i<n;i++)
    {
        cin>>weight[i];
       
       //Fill the code here 
    }
    for(i=0;i<n;i++)
    {
    if (weight[i]>= 50 && weight[i]<= 70) {
            idealCount++;
        } else if (weight[i]> 70) {
            nonIdealCount++;
        } else if (weight[i]< 50) {
            faultyCount++;
            if (faultyCount > 4) {
                std::cout << "The box contains more than four faulty eggs" << std::endl;
                return 0;
            }
        }
    }
}
    cout << "Count of eggs with ideal weight=" << idealCount ;
    cout << "Count of eggs with non-ideal weight=" << nonIdealCount;
    cout << "Count of eggs with faulty weight=" << faultyCount;

    return 0;

}

