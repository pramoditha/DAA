#include<stdio.h>
#include<math.h>
int mini(int a,int b);

int main()
{
	int n;
	printf("\nenter number of vertices:");
	scanf("%d",&n);
	int a[n][n],visited[n],i,j,distance[n],cost[n][n],path[n],count=1;
	printf("\nEnter Adjacency MAtrix:\n");
	for (i=0;i<n;i++)
	{
		for (j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
			cost[i][j]=a[i][j];
		}
		visited[i]=0;
		distance[i]=0;
	}
	visited[0]=1;
	for (i=1;i<n;i++)
	{
		distance[i]=cost[0][i];
		path[i]=0;
	}
	distance[0]=0;
	
		while (count<n)
		{
			int w,min=9999;
	for (i=1;i<n;i++)
	{
		if (distance[i]<min && visited[i]==0)
		{
			min=distance[i];
			w=i;
		}
	}
	
	visited[w]=1;
	for (i=0;i<n;i++)
	{
		if (!visited[i])
		{
			
		distance[i]=mini(distance[i],distance[w]+cost[w][i]);
		if (distance[i]==distance[w]+cost[w][i])
		{
			path[i]=w;
		}
	}
	}
	count++;
}	
printf("\n");
	for(i=0;i<n;i++)
		if(i!=0)
		{
			printf("\nDistance of node%d=%d",i,distance[i]);
			printf("\nPath=%d",i);
			
			j=i;
			do
			{
				j=path[j];
				printf("<-%d",j);
			}while(j!=0);
	}
	return 0;
}
int mini(int a,int b)
{
	
	if (a<b)
		return a;
	else
		return b;
}

