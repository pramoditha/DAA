#include<stdio.h>
void countingsort(int array[],int size)
{
	int output[20];
	int max=array[0],i;
	for(i=1;i<size;i++)
	{
		if(array[i]>max)
		max=array[i];
	}
	int count[20];
	for(i=0;i<=max;++i)
	{
		count[i]=0;
	}
	for(i=0;i<size;i++)
	{
	    count[array[i]]++;
    }
    for(i=1;i<=max;i++)
    {
    	count[i]+=count[i-1];
	}
	for(i=size-1;i>=0;i--)
	{
		output[count[array[i]]-1];
	}
	for(i=0;i<size;++i)
	{
		array[i]=output[i];
	}
}
void printarray(int array[],int size)
{
	int i;
	for(i=0;i<size;i++)
	{
		printf("%d ",array[i]);
	}
	printf("\n");
}
int main()
{
	int array[]={1,0,8,6,8,4,2,1,0,1,2,6,8,9,1};
	int n=sizeof(array)/sizeof(array[0]);
	countingsort(array,n);
	printarray(array,n);
}
