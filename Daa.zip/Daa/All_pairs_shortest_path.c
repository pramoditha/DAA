#include<stdio.h>
int main()
{
	int n,i,j,g,h;
	printf("\nenter number of vertices:");
	scanf("%d",&n);
	int a[n][n],b[n][n];
	printf("\nEnter Adjacency Matrix: (**NOTE: please enter 999 instead of infinity**)\n");
	for (i=0;i<n;i++)
		for (j=0;j<n;j++)
			scanf("%d",&a[i][j]);	
	for (i=0;i<n;i++)
	{
		for (j=0;j<n;j++)
		{
			b[i][j]=a[i][j];
			b[j][i]=a[j][i];
		}
		for (g=0;g<n;g++)
		{
			for (j=0;j<n;j++)
			{
				if (j!=i && g!=i)
				{
					if (a[g][i]==999 || a[i][j]==999)
					{
						b[g][j]=999;
					}
					else
					{
						b[g][j]=a[g][i]+a[i][j];
					}
					if (b[g][j]>a[g][j])
					{
						b[g][j]=a[g][j];
					}
				}
			}
		}
		for (g=0;g<n;g++)	
			for (j=0;j<n;j++)
				a[g][j]=b[g][j];
	}
	printf("\nAll pairs shortest path is:\n");
	for (i=0;i<n;i++)
	{
		for (j=0;j<n;j++)
	{
		printf("%d ",a[i][j]);
	}
	printf("\n");
}
	return 0;
}

