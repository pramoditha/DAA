#include<stdio.h>
int main()
{
	int n,i,j,k,m;
	printf("\nenter no, of items:");
	scanf("%d",&n);
	int v[n],p[n],w[n];
	printf("\nenter prof:");
	for (i=0;i<n;i++)
		scanf("%d",&p[i]);
	printf("\nenter weights:");
	for (i=0;i<n;i++)
		scanf("%d",&w[i]);
	for (i=0;i<n;i++)
	{	
		p[i]=p[i]*(-1);
		v[i]=1;
	}
	printf("\nenter max weight:");
	scanf("%d",&m);
	int c=m;
	printf("\ncalculating lower and upper bounds of root node");
	int u=0; 
	float l=0.0,temp=0.0;
	for (i=0;i<n;i++)
	{
		if (w[i]<=	c)
		{
		u=u+p[i];
		c=c-w[i];
		}
		else
		{
			printf("\n upper bound: %d",u);
			temp= (float) c/(float) w[i];
			l=u+(temp*p[i]);
			printf("\nlower bound : %.2f\n",l);
			break;
		}
	}
	
	for (j=0;j<n;j++)
	{
	u=0;
	c=m;
	l=0.0;
	temp=0.0;
	printf("\n %d 0",j);
	for (i=0;i<n;i++)
	{
		if ((v[i]==1) && w[i]<=c)
		{
		u=u+p[i];
		c=c-w[i];
		}
		else if (v[i]==0)
		{
			
		}
		else
		{
			printf("\nupper bound: %d",u);
			float temp= (float) c/(float) w[i];
			l=u+(temp*p[i]);
			printf("\nlower bound: %.2f\n",l);
			break;
		}
		if (i==n-1)
		{
			printf("\nupper bound: %d",u);
			float temp= (float) c/(float) w[i];
			l=u+(temp*p[i]);
			printf("\nlower bound: %.2f\n",l);
			break;
		}
	}
	v[j]=0;
	printf("\n%d 1",j);
	int u2=0;
	int c2=m;
	float l2=0.0,temp2=0.0;
	for (i=0;i<n;i++)
	{
		if ((v[i]==1) && (w[i]<=c2))
		{
		u2=u2+p[i];
		c2=c2-w[i];
		}
		else if (v[i]==0)
		{
			
		}
		else
		{
			printf("\nupper bound: %d",u2);
			float temp2= (float) c2/(float) w[i];
			l2=u2+(temp2*p[i]);
			printf("\nlower bound: %.2f\n",l2);
			break;
		}
		if (i==n-1)
		{
			printf("\nupper bound :%d",u2);
			float temp2= (float) c2/(float) w[i];
			l2=u2+(temp2*p[i]);
			printf("\nlower bound: %.2f\n",l2);
			break;
		}
	}
	
	if (l<l2)
	{
		v[j]=1;
	}
	else if (l2<l)
	{
		v[j]=0;
	}
	else if (l==l2)
	{
		if (u<=u2)
		{
			v[j]=1;
		}
		else
		{
			v[j]=0;
		}
	}
	printf("\n%d\n",j);
	if (j==n-1)
	{
		if (v[j]==0)
			printf("\ntotal profit = %.2f ",(-1)*l2);
		else
			printf("\ntotal profit = %.2f ",(-1)*l);
	}
}
for (j=i+1;j<n;j++)
	v[j]=0;
printf("\n[ ");
	for (i=0;i<n-1;i++)
		printf("%d , ",v[i]);
	printf("%d ]",v[n-1]);
	return 0;
}

